import boto3
import json
import requests
from requests_aws4auth import AWS4Auth


region = 'us-east-1' # For example, us-west-1
service = 'aoss'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

host = 'https://txjwwmxxavpt5fulgmxc.us-east-1.aoss.amazonaws.com' # The OpenSearch domain endpoint with https:// and without a trailing slash
index = 'metadata'
url = host + '/' + index + '/_search'
print("url", url)

# Lambda execution starts here
def lambda_handler(event, context):
    #print('event:', json.dumps(event))    
   
    requestbody = event['body']
    print('original body:', requestbody)
    reqBody ={}
    
    if requestbody is not None:
        reqBody.update(json.loads(requestbody))

    queryParam = event['queryStringParameters']
    if queryParam is not None:
        reqBody.update(queryParam)
   
    print("body including queryparam",reqBody)
  
    # Elasticsearch 6.x requires an explicit Content-Type header
    headers = { "Content-Type": "application/json" }

    # Make the signed HTTP request
    r = requests.post(url, auth=awsauth, headers=headers,data=json.dumps(reqBody))
    print("response ",r)
    # Create the response and add some extra content to support CORS
    response = {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": '*'
        },
        "isBase64Encoded": False
    }

    # Add the search results to the response
    response['body'] = r.text
    return response
    